This file contains the following files for hf01302: Stream network generated from the 2008 Lidar bare earth DEM

internal file name is lidar_streams.shp
fgdc metadata file is: hf01302_fgdc.xml
arcgis metadata file  is called: lidar_streams.shp.xml
projection file is called lidar_streams.prj

file updated to include stream order.

theresa valentine
January 26, 2016