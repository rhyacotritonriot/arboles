This file contains the following files for hf01301: Stream network (1976 survey), Andrews Experimental Forest
internal file name is hydro.shp
fgdc metadata file is: hf01301_fgdc.xml
arcgis metadata file  is called: hydro.shp.xml
projection file is called hydro.prj


theresa valentine
February 20, 2014